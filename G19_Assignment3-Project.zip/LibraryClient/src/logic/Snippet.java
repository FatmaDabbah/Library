package logic;

public class Snippet {

}

